#!/bin/sh

set -e

CRON_DIR=/var/spool/cron/crontabs/

# Remove the cron job for running testnet.sh and then remove that script
grep -v "testnet.sh" ${CRON_DIR}/root > ${CRON_DIR}/newroot
mv ${CRON_DIR}/newroot ${CRON_DIR}/root

rm -f /root/tools/testnet.sh
